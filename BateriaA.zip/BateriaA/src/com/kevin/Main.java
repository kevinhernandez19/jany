package com.kevin;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Created by alumno on 5/07/2017.
 */
public class Main {

    public static void main(String[] args) throws IOException {

        BufferedReader Guardar = new BufferedReader((new InputStreamReader(System.in)));
        Mascota mascota = new Mascota();
        int Mascota, Contador=0;

        System.out.println("Ingrese algun tipo de animal");
        System.out.println("");

        if(Contador=edad >)
    }

    Mascota  = new Mascota;
    int suma.Tienda;

    m1.addmascota;(new mascota);
    Edad =Guardar.readLine();


}



    )

}
