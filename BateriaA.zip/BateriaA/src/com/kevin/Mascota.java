package com.kevin;

/**
 * Created by alumno on 5/07/2017.
 */
public class Mascota {

   private String tipo_animal;
   private String raza;
   private int edad;

    public String getTipo_animal() {
        return tipo_animal;
    }

    public void setTipo_animal(String tipo_animal) {
        this.tipo_animal = tipo_animal;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setMascota(){

    public int años;

    if (getEdad()= años);

    {
       System.out.println("la suma de los años de los perros");

        if(Mascota = edad   )

mascota c1= mascota();
c1.addmascota;(new canal)
    }
}
